`make` : compile
`make run` : run
`make clean` : clean

